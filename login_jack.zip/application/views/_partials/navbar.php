<nav class="navbar">
	<a href="<?= site_url() ?>">Home</a>
	<a href="<?= site_url('article') ?>">Article</a>
	<a href="<?= site_url('search') ?>">Cari</a>
	<a href="<?= site_url('page/about') ?>">About</a>
	<a href="<?= site_url('page/contact') ?>">Contact</a>
	<a href="<?= site_url('auth/login') ?>" style="margin-left:auto">Login</a>
</nav>