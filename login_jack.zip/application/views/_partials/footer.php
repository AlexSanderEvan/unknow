<footer class="footer">
	&copy; <?= Date('Y') ?> Beritacoding.com Version 1.0.0
</footer>